<template>
  <div class="box">
    <header class="header">分类</header>
    <div class="content">分类</div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss">

</style>
