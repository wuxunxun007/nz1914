<template>
  <div class="box">
    <header class="header">购物车</header>
    <div class="content">购物车</div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss">

</style>
