require('@alipay/appx-compiler/lib/sjsEnvInit');
require('./config$');

require('../../node_modules/mini-antui/es/list/index?hash=05d2a9730dd6009bf9446182f9c985f40f8c0f43');
require('../../node_modules/mini-antui/es/list/list-item/index?hash=05d2a9730dd6009bf9446182f9c985f40f8c0f43');
require('../../pages/home/home?hash=3e2e5e2d473d03821badb5452a72c12422f436f6');
require('../../pages/index/index?hash=5158fa18297db3fbaac119609b168d20fcdf1eea');
require('../../pages/kind/kind?hash=32d7d2807ed4e666ef03b4b3fe8c38ecf2e34e68');
require('../../pages/cart/cart?hash=32d7d2807ed4e666ef03b4b3fe8c38ecf2e34e68');
require('../../pages/user/user?hash=32d7d2807ed4e666ef03b4b3fe8c38ecf2e34e68');
