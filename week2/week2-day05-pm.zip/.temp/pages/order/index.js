import Nerv from "nervjs";
import Taro, { getStorageSync as _getStorageSync } from "@tarojs/taro-h5";
import { View } from '@tarojs/components';
import { request } from "../../utils/index";
class Index extends Taro.Component {
  componentDidShow() {
    try {
      let token = _getStorageSync('token');
      request({
        url: '/order/detail',
        data: {
          token,
          orderid: this.$router.params.id
        }
      }).then(res => {
        console.log(res.data.data);
      });
    } catch (error) {}
  }
  render() {
    return <View>
        确认订单页面
        <View>地址确认</View>
        <View>商品列表确认</View>
        <View>支付方式确认</View>
      </View>;
  }

  componentDidMount() {
    super.componentDidMount && super.componentDidMount();
  }

  componentDidHide() {
    super.componentDidHide && super.componentDidHide();
  }

}

export default Index;