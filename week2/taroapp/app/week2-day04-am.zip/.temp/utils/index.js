import Taro, { showLoading as _showLoading, request as _request, hideLoading as _hideLoading } from "@tarojs/taro-h5";
const baseUrl = 'http://daxun.kuboy.top/api';

export function request(options) {
  const { url, data, method, header } = options;
  _showLoading({
    title: '加载中'
  });
  return new Promise((resolve, reject) => {
    _request({
      url: baseUrl + url,
      data: data || {},
      method: method || 'GET',
      header: header || {},
      success: res => {
        resolve(res);
      },
      fail: err => {
        reject(err);
      },
      complete: () => {
        _hideLoading();
      }
    });
  });
}