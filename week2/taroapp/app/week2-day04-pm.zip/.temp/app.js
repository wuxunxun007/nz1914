import Taro, { Component } from "@tarojs/taro-h5";
// import React, { Component } from 'react
import { Provider } from "@tarojs/redux-h5";
// import { Provider } from 'react-redux'
// import { Provider } from 'mobx-react'

// 首页代码

import configStore from "./store/index"; // 状态管理器

import './app.scss'; // 编译成为全局的app.wxss文件

// 如果需要在 h5 环境中开启 React Devtools
// 取消以下注释：
// if (process.env.NODE_ENV !== 'production' && process.env.TARO_ENV === 'h5')  {
//   require('nerv-devtools')
// }

import Nerv from 'nervjs';
import { View, Tabbar, TabbarContainer, TabbarPanel } from '@tarojs/components';
import { Router, createHistory, mountApis } from '@tarojs/router';
Taro.initPxTransform({
  "designWidth": 750,
  "deviceRatio": {
    "640": 1.17,
    "750": 1,
    "828": 0.905
  }
});

const _taroHistory = createHistory({
  mode: "hash",
  basename: "/",
  customRoutes: {},
  firstPagePath: "/pages/home/index"
});

mountApis({
  "basename": "/",
  "customRoutes": {}
}, _taroHistory);
const store = configStore(); // 创建仓库

class App extends Component {
  state = {
    __tabs: {
      color: '#333',
      selectedColor: '#f66',
      backgroundColor: '#efefef',
      borderStyle: 'white',
      list: [// 图片资源必须使用  相对路径
      {
        pagePath: "/pages/home/index",
        text: '首页',
        iconPath: require("././resources/home.png"),
        selectedIconPath: require("././resources/home_active.png")
      }, {
        pagePath: "/pages/kind/index",
        text: '分类',
        iconPath: require("././resources/kind.png"),
        selectedIconPath: require("././resources/kind_active.png")
      }, {
        pagePath: "/pages/cart/index",
        text: '购物车',
        iconPath: require("././resources/cart.png"),
        selectedIconPath: require("././resources/cart_active.png")
      }, {
        pagePath: "/pages/user/index",
        text: '我的',
        iconPath: require("././resources/user.png"),
        selectedIconPath: require("././resources/user_active.png")
      }],
      mode: "hash",
      basename: "/",
      customRoutes: {}
    }
  };


  config = { // 最终编译成为 app.json
    pages: [// 路由
    "/pages/home/index", "/pages/kind/index", "/pages/cart/index", "/pages/user/index", "/pages/index/index", "/pages/detail/index", "/pages/login/index"],
    window: { // 窗口表现
      backgroundTextStyle: 'light',
      navigationBarBackgroundColor: '#f66',
      navigationBarTitleText: 'taro项目',
      navigationBarTextStyle: 'white'
    },
    tabBar: { color: '#333', selectedColor: '#f66', backgroundColor: '#efefef', borderStyle: 'white', list: [{ pagePath: "/pages/home/index", text: '首页', iconPath: require("././resources/home.png"), selectedIconPath: require("././resources/home_active.png") }, { pagePath: "/pages/kind/index", text: '分类', iconPath: require("././resources/kind.png"), selectedIconPath: require("././resources/kind_active.png") }, { pagePath: "/pages/cart/index", text: '购物车', iconPath: require("././resources/cart.png"), selectedIconPath: require("././resources/cart_active.png") }, { pagePath: "/pages/user/index", text: '我的', iconPath: require("././resources/user.png"), selectedIconPath: require("././resources/user_active.png") }], mode: "hash",
      basename: "/",
      customRoutes: {}
    }
    // onLaunch 在微信/百度/字节跳动/支付宝小程序中这一生命周期方法对应 app 的 onLaunch
  };componentWillMount() {}
  // onLaunch 在微信/百度/字节跳动/支付宝小程序中这一生命周期方法对应 app 的 onLaunch，在 componentWillMount 后执行
  componentDidMount() {}
  // onShow
  componentDidShow() {}
  // onHide
  componentDidHide() {}
  // onError
  componentDidCatchError() {}
  // onPageNotFound 404
  componentDidNotFound() {}
  // 在 App 类中的 render() 函数没有实际作用
  // 请勿修改此函数
  render() {
    return <Provider store={store}>
          
        <TabbarContainer>
          
        <TabbarPanel>
          
                <Router mode={"hash"} history={_taroHistory} routes={[{
            path: '/pages/home/index',
            componentLoader: () => import( /* webpackChunkName: "home_index" */'./pages/home/index'),
            isIndex: true
          }, {
            path: '/pages/kind/index',
            componentLoader: () => import( /* webpackChunkName: "kind_index" */'./pages/kind/index'),
            isIndex: false
          }, {
            path: '/pages/cart/index',
            componentLoader: () => import( /* webpackChunkName: "cart_index" */'./pages/cart/index'),
            isIndex: false
          }, {
            path: '/pages/user/index',
            componentLoader: () => import( /* webpackChunkName: "user_index" */'./pages/user/index'),
            isIndex: false
          }, {
            path: '/pages/index/index',
            componentLoader: () => import( /* webpackChunkName: "index_index" */'./pages/index/index'),
            isIndex: false
          }, {
            path: '/pages/detail/index',
            componentLoader: () => import( /* webpackChunkName: "detail_index" */'./pages/detail/index'),
            isIndex: false
          }, {
            path: '/pages/login/index',
            componentLoader: () => import( /* webpackChunkName: "login_index" */'./pages/login/index'),
            isIndex: false
          }]} customRoutes={{}} />
                
        </TabbarPanel>
        <Tabbar conf={this.state.__tabs} homePage="pages/home/index" />
        </TabbarContainer>
        </Provider>;
  }

  componentWillUnmount() {
    this.componentDidHide();
  }

  constructor(props, context) {
    super(props, context);
    Taro._$app = this;
  }

}

// ReactDOM.render()
Nerv.render(<App />, document.getElementById('app'));