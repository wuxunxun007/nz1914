<template>
  <div class="detail">
    <div class="box">
      <header class="header">详情</header>
      <div class="content">详情-{{ proname }}</div>
    </div>
    <van-goods-action>
      <van-goods-action-icon icon="home-o" text="首页" @click="toHome"/>
      <van-goods-action-icon icon="shop-o" text="店铺" />
      <van-goods-action-button color="#be99ff" type="warning" text="加入购物车" @click="addCart"/>
      <van-goods-action-button color="#7232dd" type="danger" text="立即购买" />
    </van-goods-action>
  </div>
</template>
<script>
import axios from 'axios'
import Vue from 'vue'
import {
  GoodsAction,
  GoodsActionIcon,
  GoodsActionButton,
  Toast
} from 'vant'

Vue
  .use(GoodsAction)
  .use(GoodsActionIcon)
  .use(GoodsActionButton)
Vue.use(Toast)
export default {
  data () {
    return {
      proname: ''
      // proid: ''
    }
  },
  // beforeRouteUpdate (to, from, next) {
  //   console.log(to.params.proid)
  // },
  watch: {
    '$route': function (newVal) {
      console.log(newVal.params.proid)
    }
  },
  methods: {
    toHome () {
      this.$router.push('/home')
    },
    addCart () {
      console.log('addcart')
      if (!this.$store.state.user.loginstate) {
        this.$router.push('/login')
        return
      }
      axios.post('/api/cart/add', {
        token: localStorage.getItem('token'),
        userid: localStorage.getItem('userid'),
        proid: this.proid,
        num: 1
      }).then(res => {
        if (res.data.code === '10119') {
          Toast('请先登录')
          this.$router.push('/login')
        } else {
          Toast('加入购物车成功')
          this.$store.commit('changeFlag', true)
        }
      })
    }
  },
  props: ['proid'],
  mounted () {
    // console.log(this.$route)
    // let { proid } = this.$route.params
    // axios.get('/api/pro/detail?proid=' + proid).then(res => {
    //   // console.log(res.data.data)
    //   this.proname = res.data.data.proname
    //   this.proid = res.data.data.proid
    // })
    axios.get('/api/pro/detail?proid=' + this.proid).then(res => {
      // console.log(res.data.data)
      this.proname = res.data.data.proname
      this.proid = res.data.data.proid
    })
  }
}
</script>
