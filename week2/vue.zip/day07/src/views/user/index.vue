<template>
  <div class="box">
    <header class="header">个人中心头部</header>
    <div class="content">
      <div v-if="flag">
        欢迎您---{{ username }}
      </div>
      <div v-else>
        <router-link to="/login" tag="button">登录</router-link>
        <router-link to="/register" tag="button">注册</router-link>
      </div>
    </div>
  </div>
</template>
<script>
// 如果本地存在userid和token，后端校验是否正确，正确返回用户信息，不正确说明未登录
// 如果不存在userid和token,说明用户肯定没有登陆
import axios from 'axios'
export default {
  data () {
    return {
      flag: false,
      username: ''
    }
  },
  mounted () {
    axios.get('/api/users/getInfo', {
      params: {
        userid: localStorage.getItem('userid'),
        token: localStorage.getItem('token')
      }
    }).then(res => {
      console.log(res.data)
      if (res.data.code === '10119') {
        // this.$router.push('/login')
        this.flag = false
      } else {
        this.flag = true
        this.username = res.data.data.username
      }
    })
  }
}
</script>
