<template>
  <div class="box">
    <header class="header">微信支付</header>
    <div class="content">微信支付</div>
  </div>
</template>
