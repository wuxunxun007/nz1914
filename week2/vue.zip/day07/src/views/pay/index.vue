<template>
  <div class="box">
    <header class="header">选择支付方式</header>
    <div class="content">
      <input type="radio" v-model="paytype" value="wx">微信支付
      <input type="radio" v-model="paytype" value="alipay">支付宝支付

      <button @click="pay">支付</button>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import { Toast } from 'vant'
import axios from 'axios'
Vue.use(Toast)
export default {
  data () {
    return {
      paytype: 'wx'
    }
  },
  methods: {
    pay () {
      console.log('支付')
      axios.get('/api/order/updatepay', {
        params: {
          orderid: this.$route.params.orderid,
          paytype: this.paytype
        }
      }).then(() => {
        Toast('跳转到相应的支付页面')
        let path = this.paytype === 'wx' ? '/wxpay' : '/alipay'
        this.$router.push(path)
      })
    }
  }
}
</script>
