<template>
  <div class="box">
    <header class="header">支付宝支付</header>
    <div class="content">支付宝支付</div>
  </div>
</template>
