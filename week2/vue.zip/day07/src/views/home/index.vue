<template>
  <div class="box">
    <header class="header">首页头部</header>
    <div class="content">
      <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
        <van-swipe :autoplay="3000">
          <van-swipe-item v-for="(image, index) in images" :key="index">
            <img v-lazy="image" />
          </van-swipe-item>
        </van-swipe>
        <van-list
          v-model="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
        >
          <Prolist :prolist="prolist" />
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>
<script>
import Vue from 'vue'
import { List, PullRefresh, Swipe, SwipeItem, Lazyload } from 'vant'
import axios from 'axios'
import Prolist from '@/components/Prolist'
Vue.use(List)
Vue.use(PullRefresh)
Vue.use(Lazyload)
Vue.use(Swipe).use(SwipeItem)
export default {
  data () {
    return {
      images: [
        'https://img.yzcdn.cn/vant/apple-1.jpg',
        'https://img.yzcdn.cn/vant/apple-2.jpg'
      ],
      prolist: [],
      loading: false,
      finished: false,
      pageCode: 1,
      isLoading: false
    }
  },
  components: {
    Prolist
  },
  created () {
    axios.get('http://39.99.182.33/api/pro').then((res) => {
      this.prolist = res.data.data
    })
  },
  methods: {
    onLoad () {
      // List 组件通过loading和finished两个变量控制加载状态，当组件滚动到底部时，会触发load事件并将loading设置成true。此时可以发起异步操作并更新数据，数据更新完毕后，将loading设置成false即可。若数据已全部加载完毕，则直接将finished设置成true即可。
      console.log('上拉加载开始')
      this.loading = true
      this.$http.get('http://39.99.182.33/api/pro', {
        params: {
          pageCode: this.pageCode,
          limitNum: 10
        }
      }).then(res => {
        this.loading = false
        this.pageCode++ // 页面加1
        if (res.data.code === '10000') {
          this.finished = true
        } else {
          // 有数据 拼接数据
          this.prolist = [...this.prolist, ...res.data.data]
        }
      })
    },
    onRefresh () {
      // 下拉刷新时会触发 refresh 事件，在事件的回调函数中可以进行同步或异步操作，操作完成后将 v-model 设置为 false，表示加载完成。
      this.isLoading = true
      this.$http.get('http://39.99.182.33/api/pro').then((res) => {
        this.isLoading = false
        this.prolist = res.data.data
        // 页码归1
        this.pageCode = 1
        this.finished = false
      })
    }
  }
}
</script>
<style lang="scss">
.van-swipe {
  height: 180px;
  img {
    width: 100%;
  }
}
</style>
