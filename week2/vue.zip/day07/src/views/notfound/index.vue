<template>
  <div class="box">
    <header class="header">404头部</header>
    <div class="content">404内容</div>
  </div>
</template>
