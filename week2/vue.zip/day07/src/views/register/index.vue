<template>
  <div class="box">
    <header class="header">注册</header>
    <div class="content">
      <div class="registerForm">
        <input type="text" placeholder="请输入用户名" v-model.trim="username">
        <p class="tip" v-html="usernametip"></p>
        <input type="text" placeholder="请输入手机号" v-model.trim="tel">
        <p class="tip" v-html="teltip"></p>
        <div class="code">
          <input type="text" placeholder="请输入验证码" v-model.trim="code">
          <button :disabled="codeflag" @click="sendCode">{{ msg }}</button>
        </div>
        <p class="tip"  v-html="codetip"></p>
        <input type="password" placeholder="请输入密码" v-model.trim="password">
        <p class="tip"   v-html="passwordtip"></p>
        <input type="password" placeholder="再次输入密码" v-model.trim="password1">
        <p class="tip"   v-html="password1tip"></p>

        <button class="register" :disabled="!flag" @click="register" :class="{ active: flag }">注册</button>
        <div class="errortip">{{ errortip }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data () {
    return {
      username: 'wudaxun',
      tel: '18813007814',
      password: '123456',
      password1: '123456',
      code: '123456',
      adminCode: '',
      time: 10,
      msg: '发送验证码',
      codeflag: false,
      errortip: ''
    }
  },
  methods: {
    register () {
      console.log('点击了注册按钮')
      axios.post('/api/users/register', {
        username: this.username,
        tel: this.tel,
        password: this.password
      }).then(res => {
        if (res.data.code === '10001') {
          this.errortip = '该用户已注册，请直接登录'
        } else if (res.data.code === '10003') {
          this.errortip = '注册失败，请重新注册'
        } else {
          this.$router.back() // 注册成功，返回上一页
        }
      })
    },
    sendCode () {
      console.log('发验证码')
      this.codeflag = true
      this.msg = this.time + '后重新发送'
      var timer = setInterval(() => {
        this.time--
        if (this.time === 0) {
          this.time = 10
          this.msg = '发送验证码'
          this.codeflag = false
          clearInterval(timer)
        } else {
          this.msg = this.time + '后重新发送'
        }
      }, 1000)
      this.sendTelCode()
    },
    sendTelCode () {
      axios.get('/api/users/sendCode?tel=' + this.tel).then(res => {
        console.log(res.data)
        if (res.data.code === '10001') {
          this.errortip = '该用户已注册，请直接登录'
        } else if (res.data.code === '10005') {
          this.errortip = '发送验证码失败，请重新发送'
        } else {
          this.adminCode = res.data.data
        }
      })
    }
  },
  computed: {
    // 利用计算属性的依赖性生成每个表单的提示信息
    usernametip () {
      if (this.username === '') {
        return ''
      } else if (this.username.length < 6) {
        return '<span class="error">长度不能少于6位</span>'
      } else {
        return '用户名格式正确'
      }
    },
    teltip () {
      if (this.tel === '') {
        return ''
      } else if (this.tel.length !== 11) {
        return '<span class="error">请输入正确的手机号码</span>'
      } else {
        return '手机格式正确'
      }
    },
    codetip () {
      if (this.code === '') {
        return ''
      } else if (this.code * 1 !== this.adminCode && this.code !== '') {
        return '<span class="error">验证码错误</span>'
      } else {
        return '验证码正确'
      }
    },
    passwordtip () {
      if (this.password === '') {
        return ''
      } else if (this.password.length < 5) {
        return '<span class="error">密码长度必须大于5位</span>'
      } else {
        return '密码格式正确'
      }
    },
    password1tip () {
      if (this.password1 === '') {
        return ''
      } else if (this.password1 !== this.password) {
        return '<span class="error">两次验证码输入不一致</span>'
      } else {
        return '确认密码一致'
      }
    },
    flag () {
      if (this.usernametip === '用户名格式正确' && this.teltip === '手机格式正确' && this.codetip === '验证码正确' && this.passwordtip === '密码格式正确' && this.password1tip === '确认密码一致') {
        return true
      } else {
        return false
      }
    }
    // codeflag () {
    //   if (this.teltip === '手机格式正确') {
    //     return false
    //   } else {
    //     return true
    //   }
    // }
  },
  watch: {
    teltip (newVal) {
      console.log(1111)
      if (newVal === '手机格式正确') {
        this.codeflag = false
      } else {
        this.codeflag = true
      }
    }
  }
}
</script>

<style lang="scss">
.registerForm {
  width: 96%;
  margin: 30px 2%;
  input {
    display: block;
    outline: none;
    border: 0;
    width: 100%;
    border-bottom: 1px solid #efefef;
    height: 40px;
    text-indent: 10px;
  }
  .tip {
    height: 20px;
    color: lightgreen;
    font-size: 12px;
    text-align: left;
    .error {
      color: #f66;
    }
  }
  .code {
    display: flex;
    border-bottom: 1px solid #efefef;
    input {
      flex: 1;
      border: 0;
    }
    button {
      width: 120px;
      outline: none;
      border: 0;
      background: none;
    }
  }
  .register {
    display: block;
    width: 100%;
    margin: 30px 0 0 0;
    outline: none;
    border: 0;
    background: #efefef;
    height: 48px;
    color: #fff;
    font-size: 22px;
    // letter-spacing: 20px;
    font-weight: bold;
    &.active {
      background: #f66;
    }
  }
}
</style>
