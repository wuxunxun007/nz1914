<template>
  <div class="box">
    <header class="header">登录</header>
    <div class="content">
      <div class="loginForm">
        <input type="text" placeholder="请输入手机号" v-model.trim="tel">
        <p class="tip" v-html="teltip"></p>
        <input type="password" placeholder="请输入密码" v-model.trim="password">
        <p class="tip"   v-html="passwordtip"></p>
        <button class="login" :disabled="!flag" @click="login" :class="{ active: flag }">登录</button>
        <div class="errortip">{{ errortip }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data () {
    return {
      tel: '18813007814',
      password: '123456',
      errortip: ''
    }
  },
  methods: {
    login () {
      console.log('点击了登录按钮')
      axios.post('http://39.99.182.33:3000/api/users/login', {
        tel: this.tel,
        password: this.password
      }).then(res => {
        if (res.data.code === '10006') {
          this.errortip = '用户还未注册，请先注册'
        } else if (res.data.code === '10007') {
          this.errortip = '密码错误'
          this.password = ''
        } else {
          // 登陆成功，存储信息，返回上一页
          localStorage.setItem('userid', res.data.data.userid)
          localStorage.setItem('username', res.data.data.username)
          localStorage.setItem('token', res.data.data.token)
          this.$store.commit('changeLoginState', true)
          localStorage.setItem('loginstate', true)
          this.$router.back()
        }
      })
    }
  },
  computed: {
    teltip () {
      if (this.tel === '') {
        return ''
      } else if (this.tel.length !== 11) {
        return '<span class="error">请输入正确的手机号码</span>'
      } else {
        return '手机格式正确'
      }
    },
    passwordtip () {
      if (this.password === '') {
        return ''
      } else if (this.password.length < 5) {
        return '<span class="error">密码长度必须大于5位</span>'
      } else {
        return '密码格式正确'
      }
    },
    flag () {
      if (this.teltip === '手机格式正确' && this.passwordtip === '密码格式正确') {
        return true
      } else {
        return false
      }
    }
  }
}
</script>

<style lang="scss">
.loginForm {
  width: 96%;
  margin: 30px 2%;
  input {
    display: block;
    outline: none;
    border: 0;
    width: 100%;
    border-bottom: 1px solid #efefef;
    height: 40px;
    text-indent: 10px;
  }
  .tip {
    height: 20px;
    color: lightgreen;
    font-size: 12px;
    text-align: left;
    .error {
      color: #f66;
    }
  }
  .code {
    display: flex;
    border-bottom: 1px solid #efefef;
    input {
      flex: 1;
      border: 0;
    }
    button {
      width: 120px;
      outline: none;
      border: 0;
      background: none;
    }
  }
  .login {
    display: block;
    width: 100%;
    margin: 30px 0 0 0;
    outline: none;
    border: 0;
    background: #efefef;
    height: 48px;
    color: #fff;
    font-size: 22px;
    // letter-spacing: 20px;
    font-weight: bold;
    &.active {
      background: #f66;
    }
  }
}
</style>
