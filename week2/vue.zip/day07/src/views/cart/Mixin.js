export default {
  created () {
    console.log(this.cartlist)
    if (this.cartlist.length !== 0 && !this.requestflag) {
      // 状态管理器中有数据
      this.flag = false
    } else {
      // 没有数据 或者是 添加了需要重新请求数据
      this.flag = true
      this.$store.dispatch('getCartlist').then(data => {
        if (data === 1) {
          this.$router.push('/login')
        } else if (data === 2) {
          this.flag = true
        } else {
          this.flag = false
          this.$store.commit('changeFlag', false)
        }
      })
    }
  }
}
