<template>
  <div class="box">
    <header class="header">购物车</header>
    <div class="content">
      <div v-if="flag">
        购物车空空如也，<router-link to="/home">去购物</router-link>
      </div>
      <cartlist v-else/>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex'
import Cartlist from '@/components/CartList'
import Mixin from './Mixin'
export default {
  mixins: [Mixin],
  data () {
    return {
      flag: true
    }
  },
  beforeRouteEnter (to, from, next) {
    if (localStorage.getItem('loginstate') === 'true') {
      next()
    } else {
      next('/login')
    }
  },
  computed: {
    ...mapState({
      cartlist: state => state.cart.cartlist,
      requestflag: state => state.cart.flag
    })
  },
  components: {
    Cartlist
  }
}
</script>
