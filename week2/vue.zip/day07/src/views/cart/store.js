import axios from 'axios'

export default {
  state: {
    cartlist: [],
    flag: false
  },
  getters: {
    totalNumber (state) {
      let num = 0
      state.cartlist.map(item => {
        item.flag ? num += item.num : num += 0
      })
      return num
    },
    totalPrice (state) {
      let price = 0
      state.cartlist.map(item => {
        item.flag ? price += item.num * item.price : price += 0
      })
      return price
    }
  },
  actions: {
    deleteItem (context, params) {
      console.log(params.cartid)
      console.log(params.index)
      return new Promise(resolve => {
        axios.get('http://localhost:3000/api/cart/delete', {
          params: {
            token: localStorage.getItem('token'),
            cartid: params.cartid
          }
        }).then(res => {
          if (res.data.code === '10119') {
            resolve(1)
          } else {
            let arr = context.state.cartlist
            arr.splice(params.index, 1)
            context.commit({
              type: 'changeCartlist',
              data: arr
            })
            resolve(2)
          }
        })
      })
    },
    add (context, { item }) {
      return new Promise(resolve => {
        axios.get('http://localhost:3000/api/cart/update', {
          params: {
            token: localStorage.getItem('token'),
            cartid: item.cartid,
            num: item.num + 1
          }
        }).then(res => {
          console.log(res.data)
          if (res.data.code === '10119') {
            resolve(1)
          } else {
            resolve(2)
          }
        })
      })
    },
    reduce (context, { item }) {
      return new Promise(resolve => {
        axios.get('http://localhost:3000/api/cart/update', {
          params: {
            token: localStorage.getItem('token'),
            cartid: item.cartid,
            num: item.num - 1
          }
        }).then(res => {
          console.log(res.data)
          if (res.data.code === '10119') {
            resolve(1)
          } else {
            resolve(2)
          }
        })
      })
    },
    getCartlist (context) {
      return new Promise(resolve => {
        axios.get('http://localhost:3000/api/cart', {
          params: {
            userid: localStorage.getItem('userid'),
            token: localStorage.getItem('token')
          }
        }).then(res => {
          if (res.data.code === '10119') {
            resolve(1)
          } else if (res.data.code === '10012') {
            resolve(2)
          } else {
            res.data.data.map(item => {
              item.flag = true
            })
            // context.commit('changeCartlist', res.data.data)
            context.commit({
              type: 'changeCartlist',
              data: res.data.data
            })
            resolve()
          }
        })
      })
    }
  },
  mutations: {
    changeCartlist (state, data) {
      state.cartlist = data.data
    },
    changeFlag (state, data) {
      state.flag = data
    }
  }
}
