import Vue from 'vue'
import App from './App.vue'
import './registerServiceWorker'
import router from './router'
import store from './store'
import Filters from '@/filters'
import axios from 'axios'
Vue.config.productionTip = true
// Vue.filter('sexFilter', function (val) {
//   return val === 1 ? '男' : '女'
// })

Vue.filter('sexFilter', Filters.sexFilter)

// 数据请求
Vue.prototype.$http = axios
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
