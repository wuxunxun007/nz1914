import Vue from 'vue'
import VueRouter from 'vue-router'
import Footer from '@/components/Footer'
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'index',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'home',
    // component: () => import('@/views/home/index.vue')
    components: {
      default: () => import('@/views/home/index.vue'),
      footer: Footer
    }
  },
  {
    path: '/kind',
    name: 'kind',
    components: {
      default: () => import('@/views/kind/index.vue'),
      footer: Footer
    }
    // beforeEnter (to, from, next) {
    //   if (localStorage.getItem('loginstate') === 'true') {
    //     next()
    //   } else {
    //     next('/login')
    //   }
    // }
  },
  {
    path: '/cart',
    name: 'cart',
    components: {
      default: () => import('@/views/cart/index.vue'),
      footer: Footer
    }
  },
  {
    path: '/user',
    name: 'user',
    components: {
      default: () => import('@/views/user/index.vue'),
      footer: Footer
    }
  },
  {
    path: '/addresslist',
    name: 'addresslist',
    components: {
      default: () => import('@/views/addresslist/index.vue')
    }
  },
  {
    path: '/addressadd',
    name: 'addressadd',
    components: {
      default: () => import('@/views/addresslist/add.vue')
    }
  },
  {
    path: '/addressedit/:addressid',
    name: 'addressedit',
    components: {
      default: () => import('@/views/addresslist/edit.vue')
    }
  },
  {
    path: '/pay/:orderid',
    name: 'pay',
    components: {
      default: () => import('@/views/pay/index.vue')
    }
  },
  {
    path: '/wxpay',
    name: 'wxpay',
    components: {
      default: () => import('@/views/pay/wx.vue')
    }
  },
  {
    path: '/alipay',
    name: 'alipay',
    components: {
      default: () => import('@/views/pay/alipay.vue')
    }
  },
  {
    path: '/order/:orderid',
    name: 'order',
    components: {
      default: () => import('@/views/order/index.vue')
    }
  },
  // {
  //   path: '/detail',
  //   name: 'detail',
  //   components: {
  //     default: () => import('@/views/detail/index.vue')
  //   }
  // },
  {
    path: '/detail/:proid', // :proid 代表就是路由的参数
    name: 'detail',
    components: {
      default: () => import('@/views/detail/index.vue')
    },
    props: {
      default: true
    }
  },
  {
    path: '/register',
    name: 'register',
    components: {
      default: () => import('@/views/register/index.vue')
    }
  },
  {
    path: '/login',
    name: 'login',
    components: {
      default: () => import('@/views/login/index.vue')
    }
  },
  {
    path: '**',
    name: 'notfound',
    component: () => import('@/views/notfound/index.vue')
  }
]

const router = new VueRouter({
  mode: 'hash', // history
  base: process.env.BASE_URL,
  routes
})

// router.beforeEach((to, from, next) => {
//   console.log(to)
//   console.log(from)
//   // next()
//   if (to.name !== 'login') {
//     if (localStorage.getItem('loginstate') === 'true') {
//       next()
//     } else {
//       next('/login')
//     }
//   } else {
//     next()
//   }
// })

export default router
