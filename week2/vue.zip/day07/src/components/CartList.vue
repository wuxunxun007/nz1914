<template>
  <div>
    <input type="checkbox" v-model="allChecked" @change="selectAll"> 全选
    <ul class="prolist">
      <li class="item" v-for="(item, index) of cartlist" :key="item.proid">
        <input type="checkbox" v-model="item.flag" @change.stop="selectItem(item)">
        <div class="itemimg">
          <img :src="item.proimg" alt="">
        </div>
        <div class="iteminfo">
          <h3>{{ item.proname }}</h3>
          <p>{{ item.price }}</p>
          <button @click.stop="add(item)">+</button>
          {{item.num}}
          <button @click.stop="reduce(item)">-</button>
          <button @click.stop="deleteItem(item.cartid, index)">删除</button>
        </div>
      </li>
    </ul>
    <div>
      <p>总价： {{ totalPrice }}</p>
      <p>总数量：{{totalNumber}}</p>
      <!-- <button @click="submitOrder">提交订单</button> -->
    </div>
  </div>
</template>
<script>
import { mapState, mapGetters } from 'vuex'
export default {
  data () {
    return {
      allChecked: true
    }
  },
  mounted () {
    let bool = this.cartlist.every(item => item.flag === true)
    bool ? this.allChecked = true : this.allChecked = false
  },
  computed: {
    ...mapState({
      cartlist: state => state.cart.cartlist
    }),
    ...mapGetters({
      // totalNumber: this.$store.getters.totalNumber,
      // totalPrice: this.$store.getters.totalPrice
      totalNumber: 'totalNumber',
      totalPrice: 'totalPrice'
    })
  },
  methods: {
    selectAll () {
      console.log(this.allChecked)
      let arr = this.cartlist
      if (this.allChecked) {
        arr.map(item => {
          item.flag = true
        })
      } else {
        arr.map(item => {
          item.flag = false
        })
      }

      this.$store.commit({
        type: 'changeCartlist',
        data: arr
      })
    },
    selectItem (item) {
      console.log(item.flag)
      if (item.flag) {
        let bool = this.cartlist.every(item => item.flag === true)
        if (bool) {
          this.allChecked = true
        } else {
          this.allChecked = false
        }
      } else {
        this.allChecked = false
      }
    },
    deleteItem (cartid, index) {
      this.$store.dispatch('deleteItem', { cartid, index }).then(data => {
        if (data.data === 1) {
          this.$router.push('/login')
        } else {
        }
      })
    },
    add (item) {
      console.log('111')
      if (!this.$store.state.user.loginstate) {
        this.$router.push('/login')
        return
      }
      this.$store.dispatch('add', { item }).then(data => {
        if (data === 1) {
          this.$router.push('/login')
        } else {
          item.num += 1
        }
      })
    },
    reduce (item) {
      console.log('111')
      if (item.num === 1) {
        return
      }
      if (!this.$store.state.user.loginstate) {
        this.$router.push('/login')
        return
      }
      this.$store.dispatch('reduce', { item }).then(data => {
        if (data === 1) {
          this.$router.push('/login')
        } else {
          item.num -= 1
        }
      })
    }
  }
}
</script>

<style lang="scss">
@import '@/lib/reset.scss';
.prolist {

  .item {
    @include rect(100%, 1rem);
    @include flexbox();
    @include border(0 0 1px 0, #ccc, solid);
    .itemimg {
      @include rect(1rem, 1rem);
      img {
        @include rect(.9rem, .9rem);
        @include background-color(#f66);
        @include display(block);
        @include margin(0.05rem);
      }
    }
    .iteminfo {
      @include flex();
    }
  }
}
</style>
