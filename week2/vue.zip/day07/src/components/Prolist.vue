<template>
  <ul class="prolist">
    <!-- <li class="item" v-for="item of prolist" :key="item.proid">
      <div class="itemimg">
        <img :src="item.proimg" alt="">
      </div>
      <div class="iteminfo">
        <h3>{{ item.proname }}</h3>
      </div>
    </li> -->
    <!-- <router-link :to="{ name:'detail', params: { proid: item.proid}}" tag="li" class="item" v-for="item of prolist" :key="item.proid">
      <div class="itemimg">
        <img :src="item.proimg" alt="">
      </div>
      <div class="iteminfo">
        <h3>{{ item.proname }}</h3>
      </div>
    </router-link> -->
    <!-- <router-link :to="'/detail/' + item.proid" tag="li" class="item" v-for="item of prolist" :key="item.proid">
      <div class="itemimg">
        <img :src="item.proimg" alt="">
      </div>
      <div class="iteminfo">
        <h3>{{ item.proname }}</h3>
      </div>
    </router-link> -->
    <li class="item" v-for="item of prolist" @click="toDetail(item.proid)" :key="item.proid">
      <div class="itemimg">
        <img :src="item.proimg" alt="">
      </div>
      <div class="iteminfo">
        <h3>{{ item.proname }}</h3>
      </div>
    </li>
  </ul>
</template>
<script>
export default {
  props: {
    prolist: {
      type: Array
    }
  },
  methods: {
    toDetail (proid) {
      // this.$router.push('/detail/' + proid)
      // this.$router.push({ name: 'detail', params: { proid } })
      this.$router.push({ path: '/detail/' + proid })
    }
  }
}
</script>

<style lang="scss">
@import '@/lib/reset.scss';
.prolist {

  .item {
    @include rect(100%, 1rem);
    @include flexbox();
    @include border(0 0 1px 0, #ccc, solid);
    .itemimg {
      @include rect(1rem, 1rem);
      img {
        @include rect(.9rem, .9rem);
        @include background-color(#f66);
        @include display(block);
        @include margin(0.05rem);
      }
    }
    .iteminfo {
      @include flex();
    }
  }
}
</style>
