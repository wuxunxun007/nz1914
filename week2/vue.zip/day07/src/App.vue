<template>
  <div class="container">
    <transition name="slide">
      <router-view />
    </transition>
    <router-view name="footer" />
  </div>
</template>

<style lang="scss">
@import '@/lib/reset.scss';

html, body, .container, .detail {
  @include rect(100%, 100%);
}
.container, .detail {
  @include flexbox();
  @include flex-direction(column);
  .box {
    @include flex();
    @include rect(100%, auto);
    @include overflow();
    @include flexbox();
    @include flex-direction(column);
    .header {
      @include rect(100%, 0.44rem);
      @include background-color(#f66);
    }
    .content {
      @include flex();
      @include rect(100%, auto);
      @include overflow();
    }
  }
  .footer {
    @include rect(100%, 0.5rem);
    @include background-color(#efefef);

    ul {
      @include rect(100%, 100%);
      @include flexbox();
      li {
        @include flex();
        @include rect(auto, 100%);
        @include flexbox();
        @include flex-direction(column);
        @include justify-content();
        @include align-items();
        &.router-link-exact-active {
          @include color(#f66);
        }
      }
    }
  }
}
.slide-enter {
  transform: translateX(100%);
}

.slide-enter-to {
  transform: translateX(0%);
}
.slide-enter-active {
  transition: all .5s;
}

.slide-leave {
  transform: translateX(0%);
}
.slide-leave-to {
  transform: translateX(-100%);
}
.slide-leave-active {
  transition: all 0;
}
</style>
