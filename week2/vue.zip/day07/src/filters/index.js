export default {
  sexFilter (val) {
    return val === 1 ? '男' : '女'
  }
}
